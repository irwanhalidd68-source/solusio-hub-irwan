import os, io, zipfile, yaml, requests, re, json, time
import pandas as pd
import streamlit as st
from datetime import datetime, timedelta, date
from sklearn.feature_extraction.text import TfidfVectorizer
from docx import Document
from docx.shared import Pt

st.set_page_config(page_title="SOLUSIO — Hub Pak Irwan", layout="wide")

BASE = os.path.dirname(__file__)
EXPORTS = os.path.join(BASE, "exports")
DATA = os.path.join(BASE, "data")
ASSETS = os.path.join(BASE, "assets")
os.makedirs(EXPORTS, exist_ok=True)

def load_sources():
    with open(os.path.join(BASE, "sources.yaml"), "r", encoding="utf-8") as fh:
        return yaml.safe_load(fh)

def crossref_query(container, days=365, per_journal=30, lang=None, q=None, include_abstract=False):
    cutoff = (datetime.utcnow() - timedelta(days=days)).date().isoformat()
    params = {"query.container-title": container, "filter": f"from-pub-date:{cutoff}", "rows": per_journal, "sort": "published", "order": "desc"}
    if lang: params["query.language"] = lang
    if q: params["query"] = q
    url = "https://api.crossref.org/works"
    r = requests.get(url, params=params, timeout=30); r.raise_for_status()
    items = r.json().get("message", {}).get("items", [])
    rows = []
    for it in items:
        title = " ".join(it.get("title") or [])
        abstr = it.get("abstract") if include_abstract else None
        if isinstance(abstr, str):
            abstr = re.sub("<[^<]+?>", " ", abstr)
        authors = []
        for a in it.get("author", []) or []:
            nm = " ".join([a.get("given",""), a.get("family","")]).strip()
            if nm: authors.append(nm)
        journal = "; ".join(it.get("container-title") or [container])
        doi = it.get("DOI") or ""; url_item = it.get("URL") or ""
        year = None
        if it.get("issued",{}).get("date-parts"): year = it["issued"]["date-parts"][0][0]
        rows.append({"author":"; ".join(authors), "title":title, "year":year, "journal":journal, "doi":doi, "url":url_item, "abstract":abstr})
    return rows

def build_corpus(df):
    return [f"{row.get('title','')}. {row.get('abstract','') or ''}" for _, row in df.iterrows()]

def top_keywords(corpus, topk=30, ngram=(1,2)):
    if not corpus: return []
    vec = TfidfVectorizer(max_df=0.9, min_df=2, ngram_range=ngram, stop_words='english')
    X = vec.fit_transform(corpus)
    scores = X.sum(axis=0).A1; terms = vec.get_feature_names_out()
    pairs = list(zip(terms, scores)); pairs.sort(key=lambda x: x[1], reverse=True)
    return pairs[:topk]

def format_ref_style(r, style="APA"):
    author = r.get("author","").strip(); year = r.get("year",""); title = r.get("title","").strip()
    journal = r.get("journal","").strip(); doi = r.get("doi","").strip(); url = r.get("url","").strip()
    if style.upper().startswith("APA"):
        s = (f"{author} " if author else "") + (f"({year}). " if year else "") + f"{title}. " + (f"{journal}. " if journal else "")
        s += f"https://doi.org/{doi}" if doi else (url or "")
        return s.strip()
    elif style.upper().startswith("CHICAGO"):
        parts = [author, f"{year}.", f"{title}.", f"{journal}.", f"https://doi.org/{doi}" if doi else url]
        return " ".join([p for p in parts if p]).strip()
    else:  # Harvard simplified
        parts = [author + "," if author else "", f"{year}." if year else "", f"{title}.", f"{journal}.", f"Available at: https://doi.org/{doi}" if doi else (f"Available at: {url}" if url else "")]
        return " ".join([p for p in parts if p]).strip()

def to_csl_json(df):
    items = []
    for _, r in df.iterrows():
        items.append({"type":"article-journal","title":r.get("title",""),
                      "author":[{"family": a.split()[-1], "given":" ".join(a.split()[:-1])} for a in str(r.get("author","")).split("; ") if a],
                      "issued":{"date-parts":[[int(r.get("year"))]]} if str(r.get("year","")).isdigit() else None,
                      "container-title":r.get("journal",""), "DOI":r.get("doi",""), "URL":r.get("url","")})
    return {"items": items}

def to_bibtex(df):
    import re
    def slug(s): return re.sub(r'[^A-Za-z0-9]+','', s)[:20] or "ref"
    entries = []
    for _, r in df.iterrows():
        key = f"{slug(r.get('author','')).split(';')[0]}{r.get('year','')}"
        e = "@article{{{key},\n  author = {{{author}}},\n  title = {{{title}}},\n  journal = {{{journal}}},\n  year = {{{year}}},\n  doi = {{{doi}}},\n  url = {{{url}}}\n}}".format(
            key=key, author=r.get("author",""), title=r.get("title",""),
            journal=r.get("journal",""), year=r.get("year",""),
            doi=r.get("doi",""), url=r.get("url","")
        )
        entries.append(e)
    return "\n\n".join(entries)

# Header
cols = st.columns([1,3])
with cols[0]:
    p = os.path.join(ASSETS, "profile.png")
    if os.path.exists(p): st.image(p, caption="Dr. Drs. Irwan Halid, M.Si", use_container_width=True)
with cols[1]:
    st.title("Selamat datang, Pak Irwan — SOLUSIO Hub")
    st.caption("Semua alat riset & penulisan Bapak dalam satu tempat.")

tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs(["📊 Tren Isu", "✏️ Judul Unik", "📝 Metode", "📖 Book Builder", "📚 Jurnal Target", "💾 Unduh"])

with tab1:
    st.subheader("Ambil Tren Isu Administrasi Publik")
    days = st.slider("Rentang hari", 7, 720, 180, 1)
    per_journal = st.slider("Maks artikel/jurnal", 10, 100, 40, 5)
    max_journals = st.slider("Jumlah jurnal diproses", 3, 20, 12, 1)
    lang = st.selectbox("Filter bahasa", ["", "en", "id"], index=0)
    include_abstract = st.checkbox("Ambil abstrak", True)
    if st.button("▶ Jalankan", key="run_tren"):
        cfg = load_sources(); journals = cfg.get("international", []) + cfg.get("national_sinta", [])
        journals = journals[:max_journals]
        rows = []; bar = st.progress(0)
        for i, j in enumerate(journals, start=1):
            try: rows += crossref_query(j, days=days, per_journal=per_journal, lang=lang or None, include_abstract=include_abstract)
            except Exception as e: st.warning(f"Gagal dari {j}: {e}")
            bar.progress(i/len(journals))
        if rows:
            df = pd.DataFrame(rows).drop_duplicates(subset=["title"]).reset_index(drop=True)
            st.success(f"Artikel terambil: {len(df)}")
            st.dataframe(df[["journal","title","year","doi","url"]], use_container_width=True)
            corpus = build_corpus(df); pairs = top_keywords(corpus, topk=30, ngram=(1,2))
            if pairs: st.info("Top keywords: " + ", ".join([p[0] for p in pairs[:20]]))
            st.download_button("Unduh CSV", df.to_csv(index=False).encode("utf-8"), file_name="trends_report.csv", mime="text/csv")
            df.to_csv(os.path.join(EXPORTS, "trends_report.csv"), index=False, encoding="utf-8")
        else:
            st.error("Tidak ada data.")

with tab2:
    st.subheader("Generator Judul Unik")
    region = st.text_input("Konteks/Region", "Indonesia")
    domain = st.text_input("Domain", "Pelayanan Publik / Administrasi Publik")
    method = st.selectbox("Metode", ["", "Kuantitatif (Survey/SEM)", "Kualitatif (Studi Kasus)", "Mixed Methods"])
    n_titles = st.slider("Jumlah judul", 10, 100, 40, 5)
    seeds = st.text_input("Kata kunci (koma). Kosongkan untuk auto dari tren.", "")
    kws = []
    if seeds.strip():
        kws = [s.strip() for s in seeds.split(",") if s.strip()]
    else:
        tr = os.path.join(EXPORTS, "trends_report.csv")
        if os.path.exists(tr):
            try:
                df = pd.read_csv(tr)
                txt = (df["title"].fillna("") + ". " + df.get("abstract","").fillna("")).tolist()
                vec = TfidfVectorizer(max_df=0.9, min_df=2, ngram_range=(1,2), stop_words="english")
                X = vec.fit_transform(txt); scores = X.sum(axis=0).A1; terms = vec.get_feature_names_out()
                pairs = list(zip(terms, scores)); pairs.sort(key=lambda x: x[1], reverse=True)
                kws = [w for w,_ in pairs[:20]]; st.info("Auto-keywords: " + ", ".join(kws[:10]))
            except Exception as e:
                st.warning(f"Gagal auto-ekstrak kata kunci: {e}")
    if st.button("▶ Generate Titles", key="gen_titles"):
        patterns = [
            "Menakar {K1} terhadap {K2} dalam {REGION}: {METHOD} {DOMAIN}",
            "{K1}, {K2}, dan {K3}: Implikasi bagi {DOMAIN} di {REGION}",
            "Apakah {K1} Mendorong {K2}? Bukti Empiris dari {REGION}",
            "Dari {K1} ke {K2}: Kerangka {DOMAIN} untuk {REGION}",
            "Mengurai {K1} pada {DOMAIN}: Pelajaran dari {REGION}",
            "{K1} dan {K2} dalam Praktek: Evaluasi {METHOD} di {REGION}",
            "What Drives {K1} in {REGION}? Evidence for {DOMAIN}",
            "From {K1} to Outcomes: A {METHOD} Examination in {REGION}",
            "Mapping {K1} and {K2} for {DOMAIN} Transformation in {REGION}",
            "Policy Design for {K1} in {REGION}: Lessons for {DOMAIN}",
        ]
        import random
        out = []
        for _ in range(n_titles*2):
            K1 = random.choice(kws or ["digital government","service delivery","accountability"]).title()
            K2 = random.choice(kws or ["service quality","transparency","trust"]).title()
            K3 = random.choice(kws or ["governance","innovation","participation"])
            patt = random.choice(patterns)
            t = patt.format(K1=K1, K2=K2, K3=K3.title(), REGION=region, DOMAIN=domain, METHOD=(method or "Pendekatan Empiris"))
            out.append(re.sub(r"\s+"," ",t).strip())
        seen=set(); titles=[]
        for t in out:
            k=t.lower()
            if k not in seen: seen.add(k); titles.append(t)
            if len(titles)>=n_titles: break
        df_out = pd.DataFrame({"No": list(range(1,len(titles)+1)), "Judul": titles})
        st.dataframe(df_out, use_container_width=True)
        st.download_button("Unduh Judul (CSV)", df_out.to_csv(index=False).encode("utf-8"), file_name="Judul_Unik.csv", mime="text/csv")

with tab3:
    st.subheader("Metode Penelitian (Paket Dokumen)")
    desain = st.selectbox("Desain", ["Survey Kuantitatif (Cross-Sectional)", "Eksperimen Sederhana (Pretest-Posttest)", "Kualitatif (Studi Kasus)"])
    topik = st.text_input("Topik", "Adopsi Teknologi Pelayanan Publik")
    populasi = st.text_input("Populasi", "ASN Dinas X / Mahasiswa Prodi Y")
    if st.button("▶ Generate Method Pack", key="gen_method"):
        protocol_path = os.path.join(EXPORTS, "Protocol_MetodePenelitian.docx")
        d = Document(); d.add_heading(f"Studi {topik} dengan {desain}", 0)
        d.add_paragraph("Peneliti: Dr. Drs. Irwan Halid, M.Si — Universitas Muhammadiyah Gorontalo")
        d.add_heading("Metode", level=1); d.add_paragraph(f"Desain: {desain}"); d.add_paragraph(f"Populasi: {populasi}")
        d.save(protocol_path)
        st.success("Dokumen metode dibuat.")
        st.download_button("Unduh Protocol (DOCX)", open(protocol_path,"rb"), file_name="Protocol_MetodePenelitian.docx")

with tab4:
    st.subheader("Book Builder — Judul Unik + Referensi Otomatis + DOCX")
    kw = st.text_input("Kata kunci (koma)", "digital government, service quality, accountability")
    n_titles = st.slider("Jumlah judul", 10, 60, 30, 5, key="book_n")
    if st.button("▶ Buat Judul", key="book_titles"):
        def generate_titles(seed_kws, n=30, region="Indonesia"):
            seeds = [s.strip() for s in seed_kws.split(",") if s.strip()] or ["digital government","service delivery","accountability"]
            patterns = [
                "Menakar {A} terhadap {B} dalam Pelayanan Publik di {R}",
                "Dari {A} ke Kinerja Layanan: Bukti Empiris {R}",
                "Mapping {A} dan {B} untuk Transformasi Pelayanan Publik di {R}",
                "{A}, {B}, dan Kepercayaan Publik: Implikasi bagi Administrasi Publik {R}",
                "Public Value melalui {A}: Pelajaran dari {R}",
                "What Drives {A} in {R}? Evidence from Public Service",
                "Designing {A}-Driven Service Delivery: A Study in {R}",
                "Smart Public Service via {A}: Comparative Lessons from {R}",
                "Ethics and {A} in Public Administration: A Framework for {R}",
                "{A} Readiness Index for Public Service: Development and Validation in {R}",
            ]
            out=[]; import random, re
            for _ in range(n*2):
                A = random.choice(seeds).title()
                B = random.choice([x for x in seeds if x.lower()!=A.lower()]).title() if len(seeds)>1 else "Service Quality"
                patt = random.choice(patterns); t = patt.format(A=A, B=B, R="Indonesia"); out.append(re.sub(r"\s+"," ",t).strip())
            seen=set(); uniq=[]
            for t in out:
                k=t.lower()
                if k not in seen: seen.add(k); uniq.append(t)
                if len(uniq)>=n: break
            return uniq
        titles = generate_titles(kw, n_titles)
        st.dataframe(pd.DataFrame({"No": range(1,len(titles)+1), "Judul": titles}), use_container_width=True)
        st.session_state["book_title_auto"] = titles[0]
        st.success(f"Judul dipilih: {titles[0]}")

    st.divider()
    st.markdown("**Referensi Otomatis**")
    days = st.slider("Rentang hari (referensi)", 90, 720, 365, 30, key="ref_days")
    per_journal = st.slider("Maks artikel/jurnal", 10, 50, 20, 5, key="ref_rows")
    use_international = st.checkbox("Internasional (Elsevier/IEEE/Springer)", True, key="ref_int")
    use_national = st.checkbox("Nasional (Sinta 1–2)", True, key="ref_nat")
    q_filter = st.text_input("Filter teks (opsional)", "public service OR digital government", key="ref_filter")
    cite_style = st.selectbox("Gaya sitasi", ["APA (default)","Chicago","Harvard"], index=0, key="ref_style")
    if st.button("▶ Ambil Referensi", key="ref_fetch"):
        srcs = load_sources(); sel = []
        if use_international: sel += srcs.get("international", [])
        if use_national: sel += srcs.get("national_sinta", [])
        rows = []; bar = st.progress(0)
        for i, j in enumerate(sel, start=1):
            try: rows += crossref_query(j, days=days, per_journal=per_journal, q=q_filter)
            except Exception as e: st.warning(f"Gagal: {j} → {e}")
            bar.progress(i/len(sel))
        if rows:
            df_refs = pd.DataFrame(rows).drop_duplicates(subset=["title"]).reset_index(drop=True)
            st.success(f"Referensi: {len(df_refs)} artikel")
            st.dataframe(df_refs[["author","title","year","journal","doi","url"]], use_container_width=True)
            st.session_state["df_refs"] = df_refs.to_dict(orient="records")
            st.markdown("**Contoh Format (" + cite_style + ")**")
            for s in df_refs.head(5).apply(lambda r: format_ref_style(r, cite_style.split()[0]), axis=1).tolist():
                st.write("- " + s)
            st.download_button("Unduh CSV", df_refs.to_csv(index=False).encode("utf-8"), file_name="Referensi_Otomatis.csv")
            from json import dumps
            st.download_button("Unduh CSL-JSON", dumps(to_csl_json(df_refs), ensure_ascii=False, indent=2).encode("utf-8"), file_name="Referensi.csljson", mime="application/json")
            st.download_button("Unduh BibTeX", to_bibtex(df_refs).encode("utf-8"), file_name="Referensi.bib", mime="text/plain")

    st.divider()
    st.markdown("**Bangun Buku (DOCX)**")
    book_title = st.text_input("Judul Buku", st.session_state.get("book_title_auto", "Transformasi Pelayanan Publik di Era Digital"), key="book_title")
    author = st.text_input("Penulis", "Dr. Drs. Irwan Halid, M.Si", key="book_author")
    affil = st.text_input("Afiliasi", "Universitas Muhammadiyah Gorontalo", key="book_affil")
    publisher = st.text_input("Penerbit", "UMGo Press", key="book_pub")
    isbn = st.text_input("ISBN (opsional)", "", key="book_isbn")
    if st.button("▶ Buat Buku DOCX", key="book_build"):
        outline = [
            "Pendahuluan & Peta Isu Pelayanan Publik",
            "Landasan Teori: Administrasi Publik, Governance, dan Public Value",
            "Kebijakan & Regulasi Pelayanan Publik di Indonesia",
            "Desain Layanan: Standar Pelayanan, SPM, dan SAKIP",
            "Digital Government & Smart Service (G2C, G2B, G2G)",
            "Budaya Organisasi & Etika Pelayanan",
            "Inovasi & Co‑creation (Service Design, Service Blueprint)",
            "Kinerja, Akuntabilitas, dan Transparansi",
            "Studi Kasus Terpilih",
            "Roadmap & Rekomendasi Kebijakan"
        ]
        d = Document()
        p = d.add_paragraph("\n\n"); t = d.add_paragraph(book_title); t.runs[0].bold=True; t.runs[0].font.size=Pt(20)
        d.add_paragraph(author); d.add_paragraph(affil); d.add_page_break()
        d.add_heading("DAFTAR ISI", level=1); d.add_paragraph("(Buat TOC di Word: References → Table of Contents)"); d.add_page_break()
        d.add_heading("Kata Pengantar", level=1); d.add_paragraph("Buku ini menyajikan landasan teoritik dan praktik pelayanan publik."); d.add_page_break()
        for i, ch in enumerate(outline, 1):
            d.add_heading(f"Bab {i}. {ch}", level=1)
            d.add_heading("Pendahuluan", level=2); d.add_paragraph("Konteks, urgensi, tujuan.")
            d.add_heading("Kerangka Konseptual", level=2); d.add_paragraph("Teori & penelitian terkait.")
            d.add_heading("Pembahasan Utama", level=2); d.add_paragraph("Uraian inti & contoh/studi kasus.")
            d.add_heading("Implikasi Kebijakan/Praktik", level=2); d.add_paragraph("Pelajaran & rekomendasi.")
            d.add_heading("Rangkuman", level=2); d.add_paragraph("Ringkasan poin penting.")
            d.add_page_break()
        d.add_heading("Daftar Pustaka", level=1)
        df_refs = None
        if "df_refs" in st.session_state: df_refs = pd.DataFrame(st.session_state["df_refs"])
        if df_refs is not None:
            for _, r in df_refs.iterrows(): d.add_paragraph(format_ref_style(r, cite_style.split()[0]))
        else:
            d.add_paragraph("Tambahkan referensi menggunakan manajer referensi (Zotero/Mendeley).")
        out = os.path.join(EXPORTS, "Buku_AP_PelayananPublik.docx"); d.save(out)
        st.download_button("Unduh Buku (DOCX)", open(out,"rb"), file_name="Buku_AP_PelayananPublik.docx")

with tab5:
    st.subheader("Daftar Jurnal Target")
    dfj = pd.read_csv(os.path.join(DATA, "journal_targets.csv"))
    st.dataframe(dfj, use_container_width=True)
    st.download_button("Unduh CSV Jurnal Target", dfj.to_csv(index=False).encode("utf-8"), file_name="Daftar_Jurnal_Target.csv")

with tab6:
    st.subheader("Unduh Semua Keluaran")
    files = os.listdir(EXPORTS)
    if not files:
        st.info("Belum ada keluaran. Jalankan fitur lain dulu.")
    else:
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, 'w', zipfile.ZIP_DEFLATED) as z:
            for fn in files: z.write(os.path.join(EXPORTS, fn), arcname=fn)
        buffer.seek(0)
        st.download_button("Unduh ZIP Semua Output", buffer, file_name="Solusio_AllOutputs.zip")
