# SOLUSIO — Hub Pak Irwan (Streamlit Cloud)

Semua alat riset & penulisan dalam satu aplikasi:
- 📊 Tren Isu Administrasi Publik (Elsevier/IEEE/Springer + Sinta 1–2 via Crossref)
- ✏️ Generator Judul Unik (anti-kesan plagiasi)
- 📝 Metode Penelitian (dokumen protocol DOCX)
- 📖 Book Builder (judul unik + daftar pustaka + ekspor CSL-JSON/BibTeX + DOCX)
- 📚 Daftar Jurnal Target
- 💾 Unduh Semua Keluaran

## Cara Deploy (5 langkah)
1. Buat repository GitHub baru, misalnya **solusio-hub-irwan**.
2. Download ZIP ini → ekstrak → **unggah semua file** ke repo tersebut (termasuk folder `.streamlit`, `assets`, `data`, `exports`).
3. Buka **https://streamlit.io/cloud** → **New app** → pilih repo yang baru.
4. Isi:
   - **Branch**: `main`
   - **Main file**: `streamlit_app.py`
   - (Opsional) **App URL**: `solusio-hub-irwan`
5. Klik **Deploy** → akan muncul link permanen seperti:
   `https://solusio-hub-irwan.streamlit.app`

## Catatan Penting
- Aplikasi mengambil metadata artikel lewat **Crossref API**, tidak menembus paywall.
- **Daftar pustaka** di DOCX memakai format sederhana (APA/Chicago/Harvard). Rapikan akhir di Zotero/Mendeley sesuai gaya penerbit.
- Untuk hasil stabil, pastikan internet server Streamlit tidak diblokir oleh jaringan lokal.

## Struktur Folder
```
assets/            # ikon & foto profil
data/              # daftar jurnal target (CSV)
exports/           # keluaran (CSV, DOCX) akan muncul di sini saat app berjalan
streamlit_app.py   # file utama
sources.yaml       # daftar jurnal internasional & Sinta
requirements.txt   # dependensi Python
.streamlit/config.toml  # tema aplikasi
```

## Ganti Foto Header
Ganti file `assets/profile.png` (format PNG), lalu **redeploy**.

---

Dibuat khusus untuk: **Dr. Drs. Irwan Halid, M.Si** — oleh **Solusio**.
